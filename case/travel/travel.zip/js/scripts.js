
$(document).ready(function () {

    $("#menu .menu_button").click(function () {
        $(this).toggleClass("active");
    });

    //手機 上方 右側拉出選單
    $("#menu .menu_rwd_toggle").click(function () {
        $(".sidemenu_top").toggleClass("active");
        $(".menu_main").toggleClass("active");
    });

    //手機 下方 右側拉出選單(條件搜尋)
    $(".reservation_mob").click(function () {
        $(".sidemenu_bottom").addClass("active");
    });
    //手機 下方 右側拉出選單(條件搜尋) 移除
    $(".sidemenu.sidemenu_bottom .menu_rwd_toggle").click(function () {
        $(".sidemenu_bottom").removeClass("active");
        $(".sidemenu_bottom_sub").removeClass("active");
    });

    //手機 下方 右側拉出選單(副選單)
    $('.sidemenu.sidemenu_bottom .main ul li').click(function (e) {
        var $tabIndex = $(this).index();
        $(".sidemenu_bottom_sub").addClass("active");
        $('.sidemenu_bottom_sub ').eq($tabIndex).addClass("active").siblings(".sidemenu_bottom_sub ").removeClass("active");
    });

    //手機 下方 右側拉出選單(副選單) 移除
    $(".sidemenu_bottom_sub li.mm").click(function () {
        $(".sidemenu_bottom_sub").removeClass("active");
    });


    var bodyClass = document.body.classList,
        lastScrollY = 200;
    window.addEventListener('scroll', function () {
        var st = this.scrollY;
        // 判斷是向上捲動，而且捲軸超過 200px
        if (st < lastScrollY) {
            bodyClass.remove('open');
        } else {
            bodyClass.add('open');
        }
        lastScrollY = st;
    });




    //首頁輪播圖
    $('.top_big_slide').owlCarousel({
        loop: true, //循環播放
        animateOut: 'fadeOut',
        items: 1,
        margin: 0,
        autoplay: true, //自動撥放
        dots: false,
        smartSpeed: 450
    });

    //首頁輪播下方選單
    $(".reserv_main > ul > li ").click(function () {
        $(this).toggleClass('active').siblings("li").removeClass('active');
        $(".search-bar").removeClass("active");
    });

    //搜尋框 打開
    $(".search-bar_button").click(function () {
        $(".search-bar").toggleClass("active");
        $(".reserv_main > ul > li").removeClass("active");
    });
    //搜尋框 移除
    $(".search-bar_main button").click(function () {
        $(".search-bar").removeClass("active");
    });
    //地圖
    $('.map_clouds_coordinate ul li').click(function (e) {
        var $tabIndex = $(this).index();
        $(this).addClass('active').siblings(".map_clouds_coordinate ul li").removeClass('active');
        $('.map_content_box_inner > li').eq($tabIndex).fadeIn().addClass("active").siblings(".map_content_box_inner > li").hide().removeClass("active");
    });
    //map_select 手機下拉
    $("select[name*='map_select_']").change(function () {
        select_changed();
    });

    function select_changed() {
        $("li[class*='map_select-']").each(function () {
            $(this).removeClass("active");
        });
        $("select[name*='map_select_']").each(function () {
            var selected = $(this).val();
            $("." + selected).addClass("active");
        });
    }

    //三拉門
    $(".panels_outer ul li").click(function () {
        var $tabIndex = $(this).index();
        $(".panels_outer ul").addClass("active")
            .delay(1000)
            //1秒消失
            .queue(function () {
                $(".panels_outer").css({ "opacity": "0", "visibility": "hidden" });
                $(this).dequeue();
            });
        //影片打開 
        $('.panels_video li').eq($tabIndex).addClass("active").siblings(".panels_video li").removeClass("active");
        //影片撥放
        $('.panels_video li').eq($tabIndex).find("video").get(0).play().siblings(".panels_video li").find("video").get(0).pause().get(0).currentTime = 0;

    });

    //影片關閉
    $(".panels_video__close").click(function () {
        //取消1秒消失
        $(".panels_outer").removeAttr("style");
        $(".panels_outer ul").removeClass("active")
            .delay(1000)
            .queue(function () {
                //影片1秒 關閉
                $(".panels_video li").removeClass("active");
                $(this).dequeue();
            });



        // $(".panels_video").removeClass("active");

    });





    //lighrbox
    $(document).on('lity:resize', function (event, instance) {
        console.log('Lightbox resized');
    });

});



